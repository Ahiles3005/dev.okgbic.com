<?php

$MESS['C_CATALOG_SEARCH_DEFAULT_NOT_FOUND'] = 'Сожалеем, но ничего не найдено.';