<?php

$MESS['C_CATALOG_CATALOG_1_COMPARE_TITLE'] = 'Сравнение товаров';