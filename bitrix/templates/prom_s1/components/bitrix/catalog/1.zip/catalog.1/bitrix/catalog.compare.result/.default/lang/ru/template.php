<?php

$MESS['C_CATALOG_CATALOG_1_COMPARE_EMPTY'] = 'Список сравниваемых элементов пуст';
$MESS['C_CATALOG_CATALOG_1_COMPARE_DIFFERENCE'] = 'Отображать только различия';
$MESS['C_CATALOG_CATALOG_1_COMPARE_CLEAR'] = 'Очистить';