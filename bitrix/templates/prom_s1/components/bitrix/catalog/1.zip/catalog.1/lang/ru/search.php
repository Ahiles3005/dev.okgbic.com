<?php

$MESS['CATALOG_SEARCH_PAGE_TITLE'] = 'Результаты поиска';