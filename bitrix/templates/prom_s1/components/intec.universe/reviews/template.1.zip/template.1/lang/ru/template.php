<?php

$MESS['WRITE_REVIEW'] = 'Оставить отзыв';
$MESS['SEND_REVIEW'] = 'Отправить';
$MESS['NAME'] = 'Имя';
$MESS['DESCRIPTION'] = 'Отзыв';
$MESS["SOF_CONTEST"] = "Я согласен(а) на <a href='".SITE_DIR."contest/"."' target=\"_blank\">обработку персональных данных</a>";