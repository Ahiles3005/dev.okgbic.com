<?php

$MESS['WRITE_REVIEW'] = 'Write review';
$MESS['SEND_REVIEW'] = 'Send';
$MESS['NAME'] = 'Name';
$MESS['DESCRIPTION'] = 'Review';